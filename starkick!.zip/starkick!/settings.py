TOKEN = "8514563112:AAFcCqkf7jXjj1Khb6QtpRAFdwCBH9YN8nY" #сюда токен бота

admins_id = [632986293
]

SUBGRAM_TOKEN = "fdf6b45abf11d191842906493c3470315a8e69df0792e0963468b7fc87f654f8" # токен subgram
FLYER_KEY = "FL-Gelilz-tDkCoQ-iaiccB-vKzRAk"

admin_username = "@evolve404" #свой username
admin_link = "https://t.me/evolve404"

nac_1 = [2] # 1 Уровень награды за реферала
nac_2 = [2.3] # 2 Уровень награды за реферала
nac_3 = [2.6] # 3 Уровень награды за реферала

refs_boost = [0] # Количество рефералов в неделю для вывода (с бустом)
refs_noboost = [5] # Количество рефералов в неделю для вывода (без буста)

task_grant = [0.5] # Награда за задание

click_grant = [0.1] # Награда за клик

boost_cost = [599] # Стоимость буста

button_subgram = [True] 

GIFT_AMOUNT = [0.5] # ежедневый гифт
DAILY_COOLDOWN = 24 * 60 * 60 # не трогать
DELAY_TIME = 600 # Задержка на кликер (в секундах)

#основной канал
channel_osn = "https://t.me/starkick"
#чат
chater = "https://t.me/starkickchat"
id_chat = -1003303388144
#канал выплат
channel_viplat = "https://t.me/viplatistarkick"
channel_viplat_id = -1003264207782
#канал выигрышей мини-игры:
channel_link = "https://t.me/minigamesSTARKICK"
id_channel_game = -1003381713055

#Обязательная подписка
required_subscription = []

#кнопка в старте по запросу
beta_url = ""
beta_name = ""